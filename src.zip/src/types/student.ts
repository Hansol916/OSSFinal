export interface Student {
  id: number;
  name: string;
  student_number: string; // 학번
  class_number: string | null;
  created_at: string;
}
