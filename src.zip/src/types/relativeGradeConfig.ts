export interface RelativeGradeItem {
  grade: string;
  maxPercent: number;
}

export type RelativeGradeConfig = RelativeGradeItem[];
