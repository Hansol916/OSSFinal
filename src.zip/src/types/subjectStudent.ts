export interface SubjectStudent {
  id: number;
  subject_id: number;
  student_id: number;
  created_at: string;
}
