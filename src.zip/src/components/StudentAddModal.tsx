import { useState } from "react";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    name: string;
    student_number: string;
    class_number: string;
  }) => void;
}

export default function StudentAddModal({ isOpen, onClose, onSubmit }: Props) {
  const [name, setName] = useState("");
  const [studentNumber, setStudentNumber] = useState("");
  const [classNumber, setClassNumber] = useState("");

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="w-full max-w-md rounded-lg bg-white p-6 shadow-lg">
        <h2 className="mb-4 text-lg font-semibold">학생 추가</h2>

        <div className="space-y-3">
          <input
            className="w-full rounded border px-3 py-2"
            placeholder="이름"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />

          <input
            className="w-full rounded border px-3 py-2"
            placeholder="학번"
            value={studentNumber}
            onChange={(e) => setStudentNumber(e.target.value)}
          />

          <input
            className="w-full rounded border px-3 py-2"
            placeholder="분반 (예: 01)"
            value={classNumber}
            onChange={(e) => setClassNumber(e.target.value)}
          />
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="rounded px-4 py-2 text-sm text-gray-600 hover:bg-gray-100"
          >
            취소
          </button>

          <button
            onClick={() => {
              onSubmit({
                name,
                student_number: studentNumber,
                class_number: classNumber,
              });
              onClose();
            }}
            className="rounded bg-blue-600 px-4 py-2 text-sm text-white hover:bg-blue-700"
          >
            추가
          </button>
        </div>
      </div>
    </div>
  );
}
