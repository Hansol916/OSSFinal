import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import StudentGrid from "@/components/StudentGrid";
import CategoryPanel from "@/components/CategoryPanel";
import StudentAddModal from "@/components/StudentAddModal";
import AddCategoryModal from "@/components/AddCategoryModal";
import { StudentCardData } from "@/types/studentCard";
import { Category } from "@/types/category";

export default function SubjectDetailPage() {
  const router = useRouter();
  const { id } = router.query;

  // -----------------------------
  // 과목 정보 (임시)
  // -----------------------------
  const [subject] = useState({
    id: Number(id),
    name: "자료구조",
    class_number: "01",
    grading_type: "relative" as "absolute" | "relative",
  });

  const [students, setStudents] = useState<StudentCardData[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  // ⭐ 수정 중인 항목
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [isAddCategoryOpen, setIsAddCategoryOpen] = useState(false);

  // -----------------------------
  // 카테고리 fetch
  // -----------------------------
  async function fetchCategories() {
    if (!id) return;
    const res = await fetch(`/api/${id}/categories/list`);
    const json = await res.json();
    if (res.ok) setCategories(json.data);
  }

  useEffect(() => {
    fetchCategories();
  }, [id]);

  // -----------------------------
  // ⭐ 성적 항목 추가 / 수정 (분기)
  // -----------------------------
  async function handleSubmitCategory(data: {
    name: string;
    max_score: number;
    weight: number;
  }) {
    if (!id) return;

    // 🔹 수정
    if (editingCategory) {
      const res = await fetch(
        `/api/${id}/categories/${editingCategory.id}/update`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data),
        }
      );

      if (!res.ok) {
        alert("성적 항목 수정 실패");
        return;
      }
    }
    // 🔹 추가
    else {
      const res = await fetch(`/api/${id}/categories/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        alert("성적 항목 추가 실패");
        return;
      }
    }

    // 공통 후처리
    setIsAddCategoryOpen(false);
    setEditingCategory(null);
    fetchCategories();
  }

  // -----------------------------
  // 삭제
  // -----------------------------
  async function handleDeleteCategory(categoryId: number) {
    if (!confirm("이 항목을 삭제하면 모든 학생 점수가 함께 삭제됩니다."))
      return;

    const res = await fetch(`/api/${id}/categories/${categoryId}/delete`, {
      method: "DELETE",
    });

    if (!res.ok) {
      alert("삭제 실패");
      return;
    }

    fetchCategories();
  }

  // -----------------------------
  // 학생 추가 (임시 state)
  // -----------------------------
  function handleAddStudent(data: {
    name: string;
    student_number: string;
    class_number: string;
  }) {
    setStudents((prev) => [
      ...prev,
      {
        id: Date.now(),
        name: data.name,
        student_number: data.student_number,
        class_number: data.class_number,
        created_at: new Date().toISOString(),
        scores: categories.map((c) => ({
          category_id: c.id,
          category_name: c.name,
          score: null,
          max_score: c.max_score,
        })),
        total: 0,
        grade: "-",
      },
    ]);

    setIsAddStudentOpen(false);
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar />

      <main className="flex-1 px-10 py-8">
        {/* ===== 헤더 ===== */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">{subject.name}</h1>
          <p className="mt-1 text-gray-600">
            분반 {subject.class_number} · 수강 인원 {students.length}명
          </p>
        </div>

        {/* ===== 본문 ===== */}
        <div className="flex gap-8">
          {/* 성적 항목 */}
          <div className="w-80 shrink-0">
            <CategoryPanel
              categories={categories}
              onAdd={() => {
                setEditingCategory(null);
                setIsAddCategoryOpen(true);
              }}
              onEdit={(c) => {
                setEditingCategory(c);
                setIsAddCategoryOpen(true);
              }}
              onDelete={handleDeleteCategory}
            />
          </div>

          {/* 학생 영역 */}
          <div className="flex-1 rounded-lg border bg-white p-6 shadow-sm">
            <div className="mb-4 flex justify-between">
              <h2 className="text-xl text-gray-900 font-semibold">학생 목록</h2>
              <button
                onClick={() => setIsAddStudentOpen(true)}
                className="rounded-md bg-blue-600 px-5 py-2 text-sm text-white hover:bg-blue-700"
              >
                + 학생 추가
              </button>
            </div>

            <StudentGrid
              students={students}
              onScoreChange={(sid, cid, score) => console.log(sid, cid, score)}
            />
          </div>
        </div>
      </main>

      {/* ===== 모달 ===== */}
      {isAddStudentOpen && (
        <StudentAddModal
          isOpen
          onClose={() => setIsAddStudentOpen(false)}
          onSubmit={handleAddStudent}
        />
      )}

      {isAddCategoryOpen && (
        <AddCategoryModal
          initialValue={editingCategory}
          onClose={() => {
            setIsAddCategoryOpen(false);
            setEditingCategory(null);
          }}
          onSubmit={handleSubmitCategory}
        />
      )}
    </div>
  );
}
